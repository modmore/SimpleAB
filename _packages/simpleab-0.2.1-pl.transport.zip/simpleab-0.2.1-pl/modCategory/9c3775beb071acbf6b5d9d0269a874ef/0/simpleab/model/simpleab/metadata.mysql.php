<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sabTest',
    1 => 'sabVariation',
    2 => 'sabConversion',
    3 => 'sabPick',
  ),
);