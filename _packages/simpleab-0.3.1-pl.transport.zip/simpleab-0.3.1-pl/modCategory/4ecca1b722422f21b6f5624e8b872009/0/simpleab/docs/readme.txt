------------------------------------------
SimpleAB v0.3.0-pl
------------------------------------------
Author: Mark Hamstra - support@modmore.com
------------------------------------------

SimpleAB is a tool to employ A/B or multivariate testing on a MODX Revolution powered website.

It was developed by Mark Hamstra, originally for Reply.com, continued for modmore (with permission).

The current version lets you dynamically switch templates to one of several variations, as
defined in the custom manager page. It also lets you test Chunks.

For more information and documentation, please refer to https://www.modmore.com/extras/simpleab/
